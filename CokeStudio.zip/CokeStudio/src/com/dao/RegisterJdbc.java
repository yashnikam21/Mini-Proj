package com.dao;

import java.sql.*;
import java.util.*;
import com.model.Login;

public class RegisterJdbc {
	Connection con;
	PreparedStatement ps;
	int i;
	
	public Connection myConnection(){
		//1.load driver
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","System","1321");
			System.out.println("Connection to db..");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("catch connection..");
		} catch (SQLException e) {
			System.out.println("catch connection..2");
			e.printStackTrace();
		}
		return con;
	}
	
	public int saveData(List<com.model.Register> lst){
		try {
			con=myConnection();
			com.model.Register e = new com.model.Register();
			ps=con.prepareStatement("insert into REGEMP values(?,?,?,?,?)");
			ps.setInt(1,lst.get(0).getRegno());
			ps.setString(2,lst.get(0).getFname());
			ps.setString(3,lst.get(0).getUname());
			ps.setString(4, lst.get(0).getPass());
			ps.setDouble(5, lst.get(0).getSalary());
			i = ps.executeUpdate();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("test11");
			e.printStackTrace();
		}
		catch(Exception e){
			System.out.println("global.."+e);
		}
		return i;
	}
	
//	public boolean validateData(Login l) {
	//	if(l.getUname() == )
	//}
}
